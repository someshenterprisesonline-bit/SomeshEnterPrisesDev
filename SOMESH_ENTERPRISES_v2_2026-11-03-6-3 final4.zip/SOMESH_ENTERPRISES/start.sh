#!/usr/bin/env sh
# Mac / Linux: checks for the Excel reader, installs it if missing, then starts the app.
cd "$(dirname "$0")"
python3 -c "import openpyxl" 2>/dev/null || python3 -m pip install --user -r requirements.txt || python3 -m pip install --user --break-system-packages -r requirements.txt
exec python3 app.py --open "$@"
